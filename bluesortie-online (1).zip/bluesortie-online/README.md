# BLUE SORTIE ONLINE

Blue Sortie 4 をベースにしたオンライン専用版。Blue Sortie 3 / 4 の元ファイルは一切変更していません。
(Blue Sortie 4 は 3 の上位互換: フレア・敵ミサイル・敵フレアが追加されている)

## 起動 (ローカル)

```bash
npm run dev          # = npx serve .   → http://localhost:3000
```

- 通信サーバー未接続の間は **モックサーバー**(ブラウザ内)で動作します。デモルーム `ALPHA2` に入り、準備完了で出撃まで確認できます。
- `?debug` を付けると `window.BSO` (store / net / core / session) をコンソールから触れます。
- `?bots=0` で仮想フレンドを無効化。
- `?room=ABC234` を付けて開くと、PRESS START 後に自動でそのルームへ参加します(招待リンク)。

## サーバーを接続するとき

`index.html` のコメントアウトされた `window.BSO_CONFIG = { API_BASE, WS_BASE }` を有効にする
(または `?api=https://...&ws=wss://...`)。`WS_BASE` が空でなくなった時点で自動的に
`CloudflareBackend` に切り替わります。Worker / Durable Object 側の仕様は `docs/ARCHITECTURE.md`。

## テスト

```bash
npm test             # 通信層(モックサーバー + NetClient)の結合テスト
```

## デプロイ

静的ファイルのみ。Vercel に GitHub リポジトリを接続するだけで公開できます (`vercel.json` 同梱)。
Three.js は CDN (cdnjs r128) から読み込みます。

## ゲームコアについて

`js/game/game-core.js` は Blue Sortie 4 の `<script>` を `tools/build-core.py` で切り出し、
最小限のパッチ(`/*[BSO]*/` で検索可)を当てたものです。以後は直接編集して構いません。
**`build-core.py` を再実行すると game-core.js は上書きされます。**
